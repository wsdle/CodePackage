// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import '@/assets/scss/reset.scss'
import 'vant/lib/index.css'
import '@/assets/scss/global.scss'
import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import Vant, { Lazyload } from 'vant'
import axios from 'axios'
import Qs from 'qs'

Vue.use(Vant)
Vue.use(Lazyload, {
  loading: require('@/assets/images/Placeholder.png'),
  error: require('@/assets/images/ImageError.jpg')
})
Vue.prototype.$axios = axios
Vue.prototype.$qs = Qs

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>'
})
