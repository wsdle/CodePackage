<template>
	<div class="page" id="Details">
    <div class="details-header">
      <div class="details-cover">
        <img :src="cover">
      </div>
      <div class="details-info">
        <div class="details-category van-ellipsis">{{ category }}</div>
        <div class="details-name van-multi-ellipsis--l3">{{ name }}</div>
        <van-icon
          v-if="favorite"
          class="details-favorite"
          name="like"
          color="#FF8D8D"
          @click="setFavorite" />
        <van-icon
          v-else
          class="details-favorite"
          name="like-o"
          color="#FF8D8D"
          @click="setFavorite" />
      </div>
    </div>
    <div class="details-body">
      <p class="details-title">分集列表</p>
      <ul class="details-episode">
        <li
          :class="{ 'details-episode-active': active === index }"
          v-for="(item, index) in episode"
          :key="index"
          @click="selectEpisode(index)">
          <span class="van-multi-ellipsis--l3">{{ item }}</span>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import { getComicsEpisode, setFavorite } from '@/model/api'

export default {
  name: 'Details',
  data () {
    return {
      id: '', // 项目id
      name: '', // 项目名
      category: '', // 分类名
      cover: '', // 封面地址
      episode: [], // 集数
      favorite: false, // 是否标记为喜爱
      active: -1 // 分集焦点
    }
  },
  methods: {
    // 获取文件详情
    getComicsEpisode () {
      getComicsEpisode({ id: this.id })
        .then(({ data }) => {
          this.name = data.name
          this.category = data.category
          this.cover = data.cover
          this.episode = data.episode
          this.favorite = data.favorite
        })
        .catch(err => {
          throw err
        })
    },
    // 选择分集
    selectEpisode (i) {
      this.active = i
      this.$router.push({
				path: '/Browse',
        query: {
          id: this.id,
          episode: this.episode[i]
        }
			})
    },
    // 添加/删除喜爱标签
    setFavorite () {
      setFavorite({
        list: [this.id],
        value: !this.favorite
      })
        .then(res => {
          this.favorite = !this.favorite
        })
        .catch(err => {
          throw err
        })
    }
  },
  mounted () {
    this.id = this.$route.query.id
    this.getComicsEpisode()
  }
}
</script>

<style lang="scss" scoped="scoped">
#Details {
  padding: 0.5rem 0.5rem 0;
  background: #FFFFFF;
}

.details-header {
  display: flex;
  width: 100%;
  height: 6rem;
  padding: 0.5rem 0;
  margin-bottom: 1rem;
}

.details-cover {
  overflow: hidden;
  width: 8rem;
  padding-right: 0.5rem;

  img {
    max-width: 100%;
  }
}

.details-info {
  position: relative;
  width: 10.5rem;
}

.details-category {
  display: inline-block;
  max-width: 50%;
  padding: 0 0.5rem;
  border-radius: 0.6rem;
  margin: 0.5rem 0;
  background: #379BFB;
  color: #FFFFFF;
  font-size: 0.77rem;
  line-height: 1.2rem;
}

.details-name {
  overflow: hidden;
  width: 100%;
  height: 3rem;
  color: #333333;
  font-size: 0.88rem;
  font-weight: bold;
  line-height: 1rem;
}

.details-favorite {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  font-size: 1.2rem;
}

.details-body {
  border: #DFDFDF solid 1px;
}

.details-title {
  padding-left: 0.5rem;
  border-bottom: #DFDFDF solid 1px;
  font-size: 0.88rem;
  line-height: 2rem;
}

.details-episode {
  width: 100%;
  height: auto;
  min-height: 2rem;
  padding: 0 0 0.5rem 0.5rem;
  background: #EDEEF2;
  box-sizing: border-box;

  li {
    display: inline-block;
    width: auto;
    max-width: 8rem;
    height: auto;
    max-height: 4rem;
    padding: 0.5rem 1rem;
    border: #DFDFDF solid 1px;
    margin-top: 0.5rem;
    margin-right: 0.5rem;
    background: #FFFFFF;
    color: #666666;
    font-size: 0.77rem;
    vertical-align: top;
    line-height: 1rem;
    box-sizing: border-box;
  }

  &-active {
    border-color: #379BFB !important;
    color: #379BFB !important;
  }
}
</style>
