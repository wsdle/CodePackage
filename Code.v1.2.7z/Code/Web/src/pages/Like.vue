<template>
	<div class="page" id="Like">
		<div class="like-list">
			<comics-crad
				v-for="(item, index) in comicsList"
				:key="index"
				:img="item.cover"
				:desc="item.name"
				@on-click="goDetailPage(item.id)">
			</comics-crad>
		</div>
	</div>
</template>

<script>
import { getFavoriteList } from '@/model/api'
import ComicsCrad from '@/components/ComicsCrad'

export default {
	name: 'Like',
	data () {
		return {
			comicsList: [] // 项目列表
		}
	},
	methods: {
		// 前往详情页
		goDetailPage (id) {
			this.$router.push({
				path: '/Details',
				query: { id }
			})
		},
		// 获取喜爱项目列表
		getFavoriteList () {
			getFavoriteList()
				.then(({ data }) => {
					this.comicsList = data
				})
				.catch(err => {
					throw err
				})
		}
	},
	mounted () {
		this.getFavoriteList()
	},
	components: {
		ComicsCrad
	}
}
</script>

<style lang="scss" scoped="scoped">
@import '@/assets/scss/common.scss';

.like-list {
	overflow: auto;
	width: 100%;
	height: 100%;
	background: $pageBackground;
}
</style>
