<template>
	<div class="page" id="Home">
		<van-dropdown-menu class="home-menu">
			<van-dropdown-item v-model="category" :options="categoryOption" @change="switchCategory" />
		</van-dropdown-menu>
		<div class="home-list" @scroll="listScroll" ref="Home_homeList">
			<comics-crad
				v-for="(item, index) in comicsList"
				:key="index"
				:img="item.cover"
				:desc="item.name"
				@on-click="goDetailPage(item.id)">
			</comics-crad>
		</div>
	</div>
</template>

<script>
import { getComicsList, getCategoryList } from '@/model/api'
import ComicsCrad from '@/components/ComicsCrad'

export default {
	name: 'Home',
	data () {
		return {
			categoryList: [], // 类别列表
			category: 'all', // 选择的类别
			comicsList: [], // 文件列表
			isLoading: false, // 是否加载文件列表中
			page: 0, // 加载的页数
			count: 10, // 每页加载的条数
			scrollTop: 0 // 记录滚动条位置
		}
	},
	methods: {
		// 获取文件列表
		getComicsList () {
			if (this.isLoading) { return false }
			this.isLoading = true
			getComicsList({
				category: this.category,
				page: this.page,
				count: this.count
			})
				.then(({ data }) => {
					if (data.length === 0) {
						this.$toast({
							message: '到底了!  ˋ( ° ▽、° ) ',
							position: 'bottom'
						})
						return false
					}
					this.comicsList = this.comicsList.concat(data)
					this.page++
				})
				.catch(err => {
					throw err
				})
				.finally(() => {
					this.isLoading = false
				})
		},
		// 前往详情页
		goDetailPage (id) {
			this.$router.push({
				path: '/Details',
				query: { id }
			})
		},
		// 调取类别列表
		getCategoryList () {
			getCategoryList()
				.then(({ data }) => {
					this.categoryList = data
				})
				.catch(err => {
					throw err
				})
		},
		// 列表滚动到底部加载数据
		listScroll ({ target }) {
			this.scrollTop = target.scrollTop
			if (target.scrollTop + target.offsetHeight === target.scrollHeight) {
				this.getComicsList()
			}
		},
		// 根据分类筛选
		switchCategory () {
			this.comicsList = []
			this.page = 0
			this.scrollTop = 0
			this.getComicsList()
		}
	},
	computed: {
		// 获取类别列表
		categoryOption () {
			return [{ text: '全部', value: 'all' }].concat(this.categoryList.map(item => ({ text: item, value: item })))
		},
		// 获取Home页滚动条位置
		getHomeScroll () {
			return this.$store.getters.getHomeScroll
		}
	},
	mounted () {
		this.getComicsList()
		this.getCategoryList()
	},
	activated () { // 回到页面时触发
		this.$refs.Home_homeList.scrollTop = this.getHomeScroll
	},
	deactivated () { // 离开页面时触发
		this.$store.commit('setHomeScroll', this.scrollTop)
	},
	components: {
		ComicsCrad
	}
}
</script>

<style lang="scss" scoped="scoped">
@import '@/assets/scss/common.scss';

#Home {
	position: relative;
}

.home-menu {
	position: sticky;
	top: $NavigationHeight;
}

.home-list {
	overflow: auto;
	width: 100%;
	height: 100%;
	background: $pageBackground;
}
</style>
