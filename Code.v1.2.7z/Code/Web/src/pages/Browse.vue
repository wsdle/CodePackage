<template>
	<div class="page" id="Browse">
    <div class="browse-list">
      <img
        v-for="(img, index) in imageList"
        :key="index"
        v-lazy="img" />
    </div>
  </div>
</template>

<script>
import { getComicsDetail } from '@/model/api'

export default {
  name: 'Browse',
  data () {
    return {
      id: '', // 项目id
      episode: '', // 分集名
      imageList: [] // 图片列表
    }
  },
  methods: {
    // 获取文件详情
    getComicsDetail () {
      getComicsDetail({
        id: this.id,
        episode: this.episode
      })
        .then(({ data }) => {
          this.imageList = data
        })
        .catch(err => {
          throw err
        })
    }
  },
  mounted () {
    this.id = this.$route.query.id
    this.episode = this.$route.query.episode
    this.getComicsDetail()
  }
}
</script>

<style lang="scss" scoped="scoped">
.browse-list {
  overflow: auto;
  width: 100%;
  height: 100%;

  img {
    max-width: 100%;
  }
}
</style>
