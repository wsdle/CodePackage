const mutations = {
  // 设置Home页滚动条位置
  setHomeScroll (state, num) {
    state.homeScroll = num
  }
}

export default mutations
