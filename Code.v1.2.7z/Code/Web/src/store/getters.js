const getters = {
  // 获取Home页滚动条位置
  getHomeScroll (state) {
    return state.homeScroll
  }
}

export default getters
