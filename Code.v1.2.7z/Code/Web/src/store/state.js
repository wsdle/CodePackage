const state = {
  homeScroll: 0 // Home页滚动条位置
}

export default state
