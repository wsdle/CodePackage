<template>
  <div class="comicsCrad" @click="onClick">
    <div class="comicsCrad-img">
      <img v-lazy="img">
    </div>
    <div class="comicsCrad-desc van-multi-ellipsis--l2">
      {{ desc }}
    </div>
  </div>
</template>

<script>
export default {
  props: {
    img: { // 图片
      type: String,
      default: require('@/assets/images/Placeholder.png')
    },
    desc: { // 描述
      type: String,
      default: ''
    }
  },
  methods: {
    // 点击事件
    onClick () {
      this.$emit('on-click')
    }
  }
}
</script>

<style lang="scss" scoped>
$width: 9.5rem;
$padding: 0.25rem;
$line-spacing: 0.25rem;
$imgHeight: 6rem;
$descHeight: 1.6rem;

.comicsCrad {
  display: inline-block;
  width: $width;
  height: $imgHeight + $descHeight + $padding * 2;
  padding: $padding;
  margin: $line-spacing (20rem / 2 - $width) / 2;
  background: #F9F9F9;
  box-sizing: border-box;

  &-img {
		overflow: hidden;
		width: $width - $padding * 2;
		height: $imgHeight;
		background: #FAFAFA;

		img {
			max-width: 100%;
		}
	}

	&-desc {
		height: $descHeight;
		font-size: 0.66rem;
    line-height: 0.83rem;
		text-align: center;
	}
}
</style>
