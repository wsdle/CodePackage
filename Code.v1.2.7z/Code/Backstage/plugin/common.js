const MongoClient = require('mongodb').MongoClient
const Q = require('q')
const { address, directory, mongodb } = require('../settings')

exports.mongo_connect = function (database, collection) {
  const deferred = Q.defer()
  MongoClient.connect(mongodb.host, { useUnifiedTopology: true }, (err, db) => {
    if (err) {
      deferred.reject(err)
    } else {
      const dbo = db.db(database)
      deferred.resolve({ col: dbo.collection(collection), db })
    }
  })
  return deferred.promise
}

exports.toResult = function (data = null) {
  return {
    message: 'Success',
    state: 0,
    data
  }
}

exports.toError = function (message = 'Error') {
  return {
    message,
    state: 1,
    data: null
  }
}

exports.toWebPath = function (path) {
  const url = `http://${address.host}:${address.port}`
  const lastPath = path.split('/').slice(-2).join('/')
  return `${url}/download/comics/${lastPath}`
}
