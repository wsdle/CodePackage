const express = require('express')
const router = express.Router()
const { MongoClient, ObjectId } = require('mongodb')
const { mongodb } = require('../settings')
const { toResult, toError, toWebPath } = require('../plugin/common')

module.exports = router
