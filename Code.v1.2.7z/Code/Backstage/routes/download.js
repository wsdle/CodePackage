const express = require('express')
const router = express.Router()
const fs = require('fs')
const path = require('path')
const { directory } = require('../settings')

/*
* 文件流获取
*/
router.get('/comics/*', function (req, res, next) {
  const fullPath = decodeURIComponent(path.join(`${directory.Comics}${req.path.slice(req.path.indexOf('/', 1))}`))
  res.statusCode = 200
  res.setHeader('Content-Type','text/javascript;charset=UTF-8')
  const readFiles = fs.createReadStream(fullPath)
  readFiles.pipe(res)
  readFiles.on('error', err => console.log('Error path: ' + fullPath))
})

module.exports = router
