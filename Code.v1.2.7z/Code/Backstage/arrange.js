const fs = require('fs')

// 整理Comics文件夹
const root = 'G:/Disk/Library/Boutique/test'

fs.readdir(root, function (err, list) {
  list.forEach(item => {
    fs.readdir(`${root}/${item}`, function (err, files) {
      files.forEach(file => {
        const path = `${root}/${item}/${file}`
        fs.readdir(path, function (err, arr) {
          arr = arr.filter(val => val !== 'Cover.jpg')
          const newDir = `${path}/1/`
          fs.mkdir(newDir, function (err) {
            arr.forEach(fileName => {
              fs.rename(`${path}/${fileName}`, `${newDir}/${fileName}`,function (err) {
                console.log('renamed complete');
              })
            })
          })
        })
      })
    })
  })
})
