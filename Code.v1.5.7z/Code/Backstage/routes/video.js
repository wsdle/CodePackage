const fs = require('fs')
const Q = require('q')
const express = require('express')
const router = express.Router()
const { MongoClient, ObjectId } = require('mongodb')
const { mongodb, directory } = require('../settings')
const { toResult, toError, toWebPath, random, mergeArray, formatVerify } = require('../plugin/common')
const fs_readdir = Q.denodeify(fs.readdir)

const collection = 'Video'
const toPhotoWebPath = toWebPath(collection)

/*
* 获取筛选列表
*/
router.get('/getFilterList', function (req, res) {
  MongoClient.connect(mongodb.host, { useUnifiedTopology: true }, (err, db) => {
    if (err) res.json(toError('Connect error'))
    const dbo = db.db(mongodb.database)
    dbo.collection(collection).aggregate([{ $group: { _id: '$category' } }]).toArray((err, result) => {
      if (err) res.json(toError('Connect error'))
      const data = result.map(item => item._id)
      res.json(toResult(data))
      db.close()
    })
  })
})

/*
* 根据筛选条件查询数据
* @params[String] category 类别,字段为all时查询全部
* @params[Number] page 当前查询页码,从0开始
* @params[Number] count 每页查询的条数
*/
router.get('/getVideoList', function (req, res) {
  const { category, page, count } = req.query
  MongoClient.connect(mongodb.host, { useUnifiedTopology: true }, (err, db) => {
    if (err) res.json(toError('Connect error'))
    const dbo = db.db(mongodb.database)
    const whereStr = category.toLowerCase() === 'all' ? {} : { category }
    dbo.collection(collection).find(whereStr).skip(page * count).limit(+count).toArray((err, result) => {
      if (err) res.json(toError('Connect error'))
      const data = result.map(item => ({
        id: item._id,
        category: item.category,
        name: item.name,
        cover: toPhotoWebPath(item.cover),
        path: toPhotoWebPath(item.path)
      }))
      res.json(toResult(data))
      db.close()
    })
  })
})

module.exports = router
