const MongoClient = require('mongodb').MongoClient
const Q = require('q')
const { address, directory, mongodb } = require('../settings')

/*
* MongoDB数据库连接方法
* @params[String] database 数据库名
* @params[String] collection 集合名
*/
exports.mongo_connect = function (database, collection) {
  const deferred = Q.defer()
  MongoClient.connect(mongodb.host, { useUnifiedTopology: true }, (err, db) => {
    if (err) {
      deferred.reject(err)
    } else {
      const dbo = db.db(database)
      deferred.resolve({ col: dbo.collection(collection), db })
    }
  })
  return deferred.promise
}

/*
* 封装api响应值
*/
exports.toResult = function (data = null) {
  return {
    message: 'Success',
    state: 0,
    data
  }
}

/*
* 封装api错误值
*/
exports.toError = function (message = 'Error') {
  return {
    message,
    state: 1,
    data: null
  }
}

/*
* 真实地址转网络地址
* @params[String] key 资源类型
* @params[String] path 路径地址
*/
exports.toWebPath = function (key) {
  return function (path) {
    const url = `http://${address.host}:${address.port}`
    const lastPath = new RegExp(`${directory[key]}(.*)`).exec(path)[1]
    return `${url}/download/${key.toLowerCase()}${lastPath}`
  }
}

/*
* 一维数组与二维数组合并拼接成路径格式的一维数组
* @params[Array] arr1 一维数组
* @params[Array] arr2 由一维数组分化的二维数组
*/
exports.mergeArray = function (arr1, arr2) {
  const result = []
  arr1.forEach((items, i) => {
    arr2[i].forEach(item => {
      result.push(`${items}/${item}`)
    })
  })
  return result
}

/*
* 截取路径中的某一段
* @params[String] path 完整路径
* @params[Number] num 将路径"/"分隔成数组,该参数指定下标,设置负数可从后向前选择
*/
exports.cutPath = function (path, num = -1) {
  return path.split('/').slice(num)[0]
}

/*
* 格式验证
* @params[String] text 文件名
* @params[Array] arr 由文件名后缀组成的数组
*/
exports.formatVerify = function (text, arr) {
  const suffix = text.slice(text.lastIndexOf('.') + 1)
  return arr.filter(item => item.toLowerCase() === suffix.toLowerCase()).length > 0
}

/*
* 生成随机数
* @params[Number] max 最大值
* @params[Number] min 最小值
*/
exports.random = function (max, min = 0) {
  return Math.floor(Math.random() * (max - min) + min)
}

/*
* 扁平化多维数组
* @params[Array] arr 多维数组
* @params[Number] layers 扁平的层数
*/
exports.flat = function (arr, layers = 1) {
  let list = arr.map(item => item)
  for (let i = 0; i < layers; i++) {
    let list1 = []
    list.forEach(val => {
      list1 = list1.concat(val)
    })
    console.log(list1)
    list = list1
  }
  return list
}
