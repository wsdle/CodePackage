const fs = require('fs')
const rimraf = require('rimraf')
const Q = require('q')
const ffmpeg = require('fluent-ffmpeg')
const { directory, mongodb } = require('./settings')
const { mongo_connect, mergeArray, cutPath } = require('./plugin/common')

const fs_readdir = Q.denodeify(fs.readdir)
const fs_mkdir = Q.denodeify(fs.mkdir)
const fs_rimraf = Q.denodeify(rimraf)

const coverReg = /^cover\.(jpg|jpeg|png|gif)$/i
const videoReg = /.+\.(mp4|webm|ogg|avi|rmvb|flv|wmv|3gp|mkv|mov|mpg|rm|swf|ts|vob|mxf)$/i
const mp4Reg = /.+\.(mp4)$/i
const suffixReg = /\.([0-9a-zA-Z]+)$/i

class Scan {
  constructor () {
    const args = process.argv.slice(2)
    this.count = args.length
    console.log('----Scan start----')
    args.forEach(arg => {
      if (this[arg]) {
        this[arg](directory[arg])
          .then(() => this.isOver())
          .catch(err => console.error(err))
      }
    })
  }

  isOver () {
    this.count--
    if (this.count === 0) {
      console.log('----Scan end----')
    }
  }

  async Photo (path) {
    const collection = 'Photo'
    const list1 = await fs_readdir(path)
    const listEach1 = list1.map(item => fs_readdir(`${path}/${item}`))
    const list2 = mergeArray(list1, await Promise.all(listEach1))
    const listEach2 = list2.map(item => fs_readdir(`${path}/${item}`))
    const list3 = mergeArray(list2, await Promise.all(listEach2))
    const listEach3 = list3.map(item => fs_readdir(`${path}/${item}`))
    const list4 = await Promise.all(listEach3)
    const docList = list3.map((items, i) => {
      const doc = {
        category: cutPath(items, -3),
        series: cutPath(items, -2),
        name: cutPath(items, -1),
        path: `${path}/${items}`,
        cover: '',
        episode: [],
        favorite: false
      }
      list4[i].forEach(item => {
        if (coverReg.test(item)) {
          doc.cover = `${path}/${items}/${item}`
        } else {
          doc.episode.push(item)
        }
      })
      return doc
    })

    const { col, db } = await mongo_connect(mongodb.database, collection)
    const deferred = Q.defer()
    const updateData = function () {
      col.deleteMany({}, (err) => {
        if (err) deferred.reject(err)
        col.insertMany(docList, (err, obj) => {
          deferred.resolve(obj)
          db.close()
        })
      })
      return deferred.promise
    }
    const res = await updateData()
    console.log(`${collection}成功插入${res.result.n}条数据`)
  }

  async Comics (path) {
    const collection = 'Comics'
    const list1 = await fs_readdir(path)
    const listEach1 = list1.map(item => fs_readdir(`${path}/${item}`))
    const list2 = mergeArray(list1, await Promise.all(listEach1))
    const listEach2 = list2.map(item => fs_readdir(`${path}/${item}`))
    const list3 = await Promise.all(listEach2)
    const docList = list2.map((items, i) => {
      const doc = {
        category: cutPath(items, -2),
        name: cutPath(items, -1),
        path: `${path}/${items}`,
        cover: '',
        episode: [],
        favorite: false
      }
      list3[i].forEach(item => {
        if (coverReg.test(item)) {
          doc.cover = `${path}/${items}/${item}`
        } else {
          doc.episode.push(item)
        }
      })
      return doc
    })

    const { col, db } = await mongo_connect(mongodb.database, collection)
    const deferred = Q.defer()
    const updateData = function () {
      col.deleteMany({}, (err) => {
        if (err) deferred.reject(err)
        col.insertMany(docList, (err, obj) => {
          deferred.resolve(obj)
          db.close()
        })
      })
      return deferred.promise
    }
    const res = await updateData()
    console.log(`${collection}成功插入${res.result.n}条数据`)
  }

  async Video (path) {
    const collection = 'Video'
    const content = `${path}/本体`
    const cover = `${path}/封面`
    const queue = [] // 视频队列
    const docList = [] // 视频信息队列
    const deferred = Q.defer()

    // 清空封面文件夹
    await fs_rimraf(cover)
    await fs_mkdir(cover)

    recursion('')
    const { col, db } = await mongo_connect(mongodb.database, collection)
    col.deleteMany({}, (err) => {
      col.insertMany(docList, (err, res) => {
        handle(queue)
        console.log(`${collection}成功插入${res.result.n}条数据`)
        db.close()
      })
    })

    function recursion (path) { // 将文件夹内所有视频文件加入视频队列
      const sortList = fs.readdirSync(`${content}${path}`)
      sortList.forEach(function (dir) {
        const stats = fs.statSync(`${content}${path}/${dir}`)
        if (stats.isFile()) {
          if (!videoReg.test(dir)) return null
          queue.push({ path, dir })
          docList.push({
            category: path.indexOf('/', 1) < 0 ? path.slice(1) : path.slice(1, path.indexOf('/', 1)),
            name: dir.slice(0, dir.lastIndexOf('.')),
            path: `${content}${path}/${mp4Reg.test(dir) ? dir : `${dir}.mp4`}`,
            cover: `${cover}${path}/${dir}.png`,
            favorite: false
          })
        } else {
          recursion(`${path}/${dir}`)
        }
      })
    }

    function handle (arr) { // 处理视频队列
      if (arr.length === 0) {
        deferred.resolve()
        return null
      }
      const o = arr.shift()
      ffmpeg(`${content}${o.path}/${o.dir}`)
        .screenshots({
          timestamps: ['8%'],
          filename: `${o.dir}.png`,
          folder: `${cover}${o.path}`
        })
        .on('end', function() {
          if (!mp4Reg.test(o.dir)) {
            ffmpeg(`${content}${o.path}/${o.dir}`)
              .format('mp4')
              .save(`${content}${o.path}/${o.dir}.mp4`)
              .on('end', function() {
                fs.unlink(`${content}${o.path}/${o.dir}`, function (err) {
                  handle(arr)
                })
              })
              .on('error', function(err) {
                console.log(`ffmpeg error: ${content}${o.path}/${o.dir}`)
              })
          } else {
            handle(arr)
          }
        })
        .on('error', function(err) {
          console.log(`ffmpeg error: ${content}${o.path}/${o.dir}`)
        })
    }

    return deferred.promise
  }
}

new Scan()
