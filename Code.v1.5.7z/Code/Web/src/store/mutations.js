const mutations = {
  // 设置Comics页滚动条位置
  setComicsListScroll (state, num) {
    state.comicsListScroll = num
  },
  // 设置Photo页滚动条位置
  setPhotoListScroll (state, num) {
    state.photoListScroll = num
  },
  // 设置Video页滚动条位置
  setVideoListScroll (state, num) {
    state.videoListScroll = num
  },
  // 设置Like页选项卡焦点记录
  setLikeActive (state, str) {
    state.likeActive = str
  }
}

export default mutations
