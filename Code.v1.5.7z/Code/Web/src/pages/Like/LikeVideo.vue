<template>
  <div id="LikeVideo">
    <div class="likeVideo-list">
			<crad
				v-for="(item, index) in videoList"
				:key="index"
				:img="item.cover"
				:desc="cutPath(item.path)"
				@on-click="goPlayerPage(item)">
			</crad>
		</div>
  </div>
</template>

<script>
import Crad from '@/components/Crad'
import { getFavoriteList } from '@/model/api'

export default {
  name: 'LikeVideo',
  data () {
		return {
			videoList: [] // 项目列表
		}
	},
	methods: {
		// 前往视频播放页
    goPlayerPage (info) {
      this.$router.push({
				path: '/VideoPlayer',
				query: info
			})
    },
		// 获取喜爱项目列表
		getFavoriteList () {
			getFavoriteList({ type: 'Video' })
				.then(({ data }) => {
          this.videoList = data
				})
				.catch(err => {
					throw err
				})
    },
    // 截取路径
    cutPath (path) {
      return path.replace('http://10.157.147.41:3000/download/video/本体/', '').replace('.mp4', '')
    }
	},
	mounted () {
		this.getFavoriteList()
	},
	components: {
		Crad
	}
}
</script>

<style lang="scss" scoped>
@import '@/assets/scss/common.scss';

.likeVideo-list {
	overflow: auto;
	width: 100%;
	height: 100%;
	background: $pageBackground;
}
</style>
