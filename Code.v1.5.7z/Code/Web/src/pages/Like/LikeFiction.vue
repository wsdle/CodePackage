<template>
  <div id="LikeFiction">LikeFiction</div>
</template>

<script>
export default {
  name: 'LikeFiction'
}
</script>

<style lang="scss" scoped>

</style>
