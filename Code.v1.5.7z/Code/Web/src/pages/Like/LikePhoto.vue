<template>
	<div class="page" id="LikePhoto">
		<div class="likePhoto-list">
			<crad
				v-for="(item, index) in photoList"
				:key="index"
				:img="item.cover"
				:desc="item.name"
				@on-click="goDetailPage(item.id)">
			</crad>
		</div>
	</div>
</template>

<script>
import Crad from '@/components/Crad'
import { getFavoriteList } from '@/model/api'

export default {
	name: 'LikePhoto',
	data () {
		return {
			photoList: [] // 项目列表
		}
	},
	methods: {
		// 前往详情页
		goDetailPage (id) {
			this.$router.push({
				path: '/PhotoDetails',
				query: { id }
			})
		},
		// 获取喜爱项目列表
		getFavoriteList () {
			getFavoriteList({ type: 'Photo' })
				.then(({ data }) => {
					this.photoList = data
				})
				.catch(err => {
					throw err
				})
		}
	},
	mounted () {
		this.getFavoriteList()
	},
	components: {
		Crad
	}
}
</script>

<style lang="scss" scoped="scoped">
@import '@/assets/scss/common.scss';

.likePhoto-list {
	overflow: auto;
	width: 100%;
	height: 100%;
	background: $pageBackground;
}
</style>
