<template>
  <div id="LikeMovie">LikeMovie</div>
</template>

<script>
export default {
  name: 'LikeMovie'
}
</script>

<style lang="scss" scoped>

</style>
