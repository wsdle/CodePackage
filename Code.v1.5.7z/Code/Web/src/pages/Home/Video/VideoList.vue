<template>
  <div class="page" id="VideoList">
    <van-dropdown-menu class="videoList-menu">
			<van-dropdown-item v-model="category" :options="categoryOption" @change="switchCategory" />
		</van-dropdown-menu>
    <div class="videoList-list" @scroll="listScroll" ref="videoList_list">
      <crad
				v-for="(item, index) in videoList"
				:key="index"
				:img="item.cover"
				:desc="cutPath(item.path)"
				@on-click="goPlayerPage(item)">
			</crad>
    </div>
  </div>
</template>

<script>
import Crad from '@/components/Crad'
import { getVideoFilterList, getVideoList } from '@/model/api'

export default {
  name: 'VideoList',
  data () {
    return {
      category: 'all', // 类别
      categoryList: [], // 类别列表
      videoList: [], // 项目列表
      isLoading: false, // 是否加载列表中
			page: 0, // 加载的页数
      count: 10, // 每页加载的条数
      scrollTop: 0 // 记录滚动条位置
    }
  },
  methods: {
    // 前往视频播放页
    goPlayerPage (info) {
      this.$router.push({
				path: '/VideoPlayer',
				query: info
			})
    },
    // 获取筛选列表
    getFilterList () {
      getVideoFilterList()
        .then(({ data }) => {
          this.categoryList = data
        })
        .catch(err => {
          throw err
        })
    },
    // 切换类别
    switchCategory () {
      this.page = 0
      this.scrollTop = 0
      this.videoList = []
      this.getVideoList()
    },
    // 获取视频列表
    getVideoList () {
      if (this.isLoading) { return false }
			this.isLoading = true
      getVideoList({
        category: this.category,
        page: this.page,
        count: this.count
      })
        .then(({ data }) => {
          if (data.length === 0) {
						this.$toast({
							message: '到底了!  ˋ( ° ▽、° ) ',
							position: 'bottom',
							duration: 800
						})
						return false
					}
					this.videoList = this.videoList.concat(data)
					this.page++
        })
        .catch(err => {
          throw err
        })
        .finally(() => {
					this.isLoading = false
				})
    },
    // 列表滚动到底部加载数据
    listScroll ({ target }) {
      this.scrollTop = target.scrollTop
			if (target.scrollTop + target.offsetHeight === target.scrollHeight) {
				this.getVideoList()
			}
    },
    // 截取路径
    cutPath (path) {
      return path.replace('http://10.157.147.41:3000/download/video/本体/', '').replace('.mp4', '')
    }
  },
  computed: {
    // 获取类别列表
		categoryOption () {
			return [{ text: '全部', value: 'all' }].concat(this.categoryList.map(item => ({ text: item, value: item })))
    },
    // 获取VideoList页滚动条位置
		getVideoListScroll () {
			return this.$store.getters.getVideoListScroll
		}
  },
  mounted () {
    this.getFilterList()
    this.getVideoList()
  },
  activated () { // 回到页面时触发
		this.$refs.videoList_list.scrollTop = this.getVideoListScroll
	},
	deactivated () { // 离开页面时触发
		this.$store.commit('setVideoListScroll', this.scrollTop)
	},
  components: {
    Crad
  }
}
</script>

<style lang="scss" scoped>
@import '@/assets/scss/common.scss';

#VideoList {
	position: relative;
	padding-top: $menuHeight;
}

.videoList-menu {
	position: fixed;
	top: $NavigationHeight;
	left: 0;
	width: 100%;
}

.videoList-list {
	overflow: auto;
	width: 100%;
	height: 100%;
	background: $pageBackground;
}
</style>
