<template>
  <div id="VideoRecommend">
    <scroll-navigation :title="title" />
    <div class="videoRecommend-content">
      <vueMiniPlayer :video="playerOptions" :mutex="true" />
    </div>
    <div class="videoRecommend-favorite" @click="setFavorite">
      <van-icon v-if="favorite" name="like" color="#FF8D8D" size="1.5rem" />
      <van-icon v-else name="like-o" color="#FFFFFF" size="1.5rem" />
    </div>
    <div class="videoRecommend-reset" @click="resetList">
      <van-icon name="replay" color="#FFFFFF" size="1.5rem" />
    </div>
  </div>
</template>

<script>
export default {
  name: 'VideoRecommend'
}
</script>

<style lang="scss" scoped>

</style>
