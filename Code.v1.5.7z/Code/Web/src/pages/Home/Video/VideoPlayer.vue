<template>
  <div id="VideoPlayer">
    <scroll-navigation :title="title" />
    <div class="videoPlayer-content">
      <vueMiniPlayer :video="playerOptions" :mutex="true" />
    </div>
    <div class="videoPlayer-favorite" @click="setFavorite">
      <van-icon v-if="favorite" name="like" color="#FF8D8D" size="1.5rem" />
      <van-icon v-else name="like-o" color="#FFFFFF" size="1.5rem" />
    </div>
  </div>
</template>

<script>
import ScrollNavigation from '@/components/ScrollNavigation'
import { setFavorite } from '@/model/api'

export default {
  name: 'VideoPlayer',
  data () {
    return {
      id: '', // 当前id
      favorite: false // 是否标记为喜爱
    }
  },
  methods: {
    // 设置喜爱标签
    setFavorite () {
      setFavorite({
        type: 'Video',
        list: [this.id],
        value: !this.favorite
      })
        .then(res => {
          this.favorite = !this.favorite
        })
        .catch(err => {
          throw err
        })
    }
  },
  computed: {
    // 标题栏文字
    title () {
      return this.$route.query.path.replace('http://10.157.147.41:3000/download/video/本体/', '')
    },
    // 播放器设置
    playerOptions () {
      return {
        url: this.$route.query.path,
        cover: this.$route.query.cover,
        muted: false,
        loop: false,
        preload: 'auto',
        poster: '',
        volume: 1,
        autoplay: false
      }
    }
  },
  mounted () {
    this.id = this.$route.query.id
  },
  components: {
    ScrollNavigation
  }
}
</script>

<style lang="scss" scoped>
@import '@/assets/scss/common.scss';

#VideoPlayer {
  width: 100%;
  height: 100%;
  padding-top: $NavigationHeight;
  background: #000000;
  box-sizing: border-box;
}

.videoPlayer-content {
  width: 100%;
  height: 100%;
}

.videoPlayer-favorite {
  display: flex;
  justify-content: center;
  align-items: center;
  position: fixed;
  bottom: 3rem;
  right: 1rem;
  width: 2rem;
  height: 2rem;
  border-radius: 1rem;
  background: #000000;
  color: #FFFFFF;
  opacity: 0.6;
}
</style>
