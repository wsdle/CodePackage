<template>
	<div class="page" id="ComicsDetails">
    <div class="comicsDetails-header">
      <div class="comicsDetails-cover">
        <img :src="cover">
      </div>
      <div class="comicsDetails-info">
        <div class="comicsDetails-category van-ellipsis">{{ category }}</div>
        <div class="comicsDetails-name van-multi-ellipsis--l3">{{ name }}</div>
        <van-icon
          v-if="favorite"
          class="comicsDetails-favorite"
          name="like"
          color="#FF8D8D"
          @click="setFavorite" />
        <van-icon
          v-else
          class="comicsDetails-favorite"
          name="like-o"
          color="#FF8D8D"
          @click="setFavorite" />
      </div>
    </div>
    <div class="comicsDetails-body">
      <p class="comicsDetails-title">分集列表</p>
      <ul class="comicsDetails-episode">
        <li
          :class="{ 'comicsDetails-episode-active': active === index }"
          v-for="(item, index) in episode"
          :key="index"
          @click="selectEpisode(index)">
          <span class="van-multi-ellipsis--l3">{{ item }}</span>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import { getComicsEpisode, setFavorite } from '@/model/api'

export default {
  name: 'ComicsDetails',
  data () {
    return {
      id: '', // 项目id
      name: '', // 项目名
      category: '', // 分类名
      cover: '', // 封面地址
      episode: [], // 集数
      favorite: false, // 是否标记为喜爱
      active: -1 // 分集焦点
    }
  },
  methods: {
    // 获取文件详情
    getComicsEpisode () {
      getComicsEpisode({ id: this.id })
        .then(({ data }) => {
          this.name = data.name
          this.category = data.category
          this.cover = data.cover
          this.episode = data.episode
          this.favorite = data.favorite
        })
        .catch(err => {
          throw err
        })
    },
    // 选择分集
    selectEpisode (i) {
      this.active = i
      this.$router.push({
				path: '/ComicsBrowse',
        query: {
          id: this.id,
          episode: this.episode[i]
        }
			})
    },
    // 添加/删除喜爱标签
    setFavorite () {
      setFavorite({
        type: 'Comics',
        list: [this.id],
        value: !this.favorite
      })
        .then(res => {
          this.favorite = !this.favorite
        })
        .catch(err => {
          throw err
        })
    }
  },
  mounted () {
    this.id = this.$route.query.id
    this.getComicsEpisode()
  }
}
</script>

<style lang="scss" scoped="scoped">
@import '@/assets/scss/common.scss';

#ComicsDetails {
  padding: 0.5rem 0.5rem 0;
  background: #FFFFFF;
}

.comicsDetails-header {
  display: flex;
  width: 100%;
  height: 6rem;
  padding: 0.5rem 0;
  margin-bottom: 1rem;
}

.comicsDetails-cover {
  overflow: hidden;
  width: 8rem;
  margin-right: 0.5rem;
  background: $pageBackground;

  img {
    min-width: 100%;
    max-width: 100%;
  }
}

.comicsDetails-info {
  position: relative;
  width: 10.5rem;
}

.comicsDetails-category {
  display: inline-block;
  max-width: 50%;
  padding: 0 0.5rem;
  border-radius: 0.6rem;
  margin: 0.5rem 0;
  background: #379BFB;
  color: #FFFFFF;
  font-size: 0.77rem;
  line-height: 1.2rem;
}

.comicsDetails-name {
  overflow: hidden;
  width: 100%;
  height: 3rem;
  color: #333333;
  font-size: 0.88rem;
  font-weight: bold;
  line-height: 1rem;
}

.comicsDetails-favorite {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  font-size: 1.2rem;
}

.comicsDetails-body {
  border: #DFDFDF solid 1px;
}

.comicsDetails-title {
  padding-left: 0.5rem;
  border-bottom: #DFDFDF solid 1px;
  font-size: 0.88rem;
  line-height: 2rem;
}

.comicsDetails-episode {
  width: 100%;
  height: auto;
  min-height: 2rem;
  padding: 0 0 0.5rem 0.5rem;
  background: #EDEEF2;
  box-sizing: border-box;

  li {
    display: inline-block;
    width: auto;
    max-width: 8rem;
    height: auto;
    max-height: 4rem;
    padding: 0.5rem 1rem;
    border: #DFDFDF solid 1px;
    margin-top: 0.5rem;
    margin-right: 0.5rem;
    background: #FFFFFF;
    color: #666666;
    font-size: 0.77rem;
    vertical-align: top;
    line-height: 1rem;
    box-sizing: border-box;
  }

  &-active {
    border-color: #379BFB !important;
    color: #379BFB !important;
  }
}
</style>
