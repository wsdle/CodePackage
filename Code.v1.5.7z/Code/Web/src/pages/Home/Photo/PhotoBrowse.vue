<template>
	<div class="page" id="PhotoBrowse">
    <div class="photoBrowse-list">
      <div
        class="photoBrowse-box"
        v-for="(item, index) in list"
        :key="index">
        <img v-lazy="item" />
      </div>
    </div>
  </div>
</template>

<script>
import { getPhotoImages } from '@/model/api'

export default {
  name: 'PhotoBrowse',
  data () {
    return {
      id: '', // 项目id
      episode: '', // 分集名
      list: [] // 图片列表
    }
  },
  methods: {
    // 获取所有图片
    getImages () {
      getPhotoImages({
        id: this.id,
        episode: this.episode
      })
        .then(({ data }) => {
          this.list = data
        })
        .catch(err => {
          throw err
        })
    }
  },
  mounted () {
    this.id = this.$route.query.id
    this.episode = this.$route.query.episode
    this.getImages()
  }
}
</script>

<style lang="scss" scoped="scoped">
.photoBrowse-list {
  overflow: auto;
  width: 100%;
  height: 100%;
}

.photoBrowse-box {
  width: 100%;

  img {
    max-width: 100%;
  }
}
</style>
