const fs = require('fs')
const Q = require('q')
const { directory, mongodb } = require('./settings')
const { mongo_connect } = require('./plugin/common')

const fs_readdir = Q.denodeify(fs.readdir)

class Scan {
  constructor () {
    const args = process.argv.slice(2)
    this.count = args.length
    console.log('----Scan start----')
    args.forEach(arg => {
      if (this[arg]) {
        this[arg](directory[arg])
          .then(() => this.isOver())
          .catch(err => console.error(err))
      }
    })
  }

  isOver () {
    this.count--
    if (this.count === 0) {
      console.log('----Scan end----')
    }
  }

  async Comics (path) {
    const collection = 'Comics'
    const list = await fs_readdir(path)
    const listEach = list.map(item => fs_readdir(`${path}/${item}`))
    const dirList = await Promise.all(listEach)
    let docList = []
    for (let i = 0; i < dirList.length; i++) {
      for (let j = 0; j < dirList[i].length; j++) {
        docList.push({
          category: list[i],
          name: dirList[i][j],
          path: `${path}/${list[i]}/${dirList[i][j]}`
        })
      }
    }
    const docEach = docList.map(item => {
      return fs_readdir(item.path)
        .then(res => {
          const arr = res.filter(val => val !== 'Cover.jpg')
          item.episode = arr
          return item
        })
    })
    docList = await Promise.all(docEach)

    const { col, db } = await mongo_connect(mongodb.database, collection)
    const deferred = Q.defer()
    const updateData = function () {
      col.deleteMany({}, (err) => {
        if (err) deferred.reject(err)
        col.insertMany(docList, (err, obj) => {
          deferred.resolve(obj)
          db.close()
        })
      })
      return deferred.promise
    }
    const res = await updateData()
    console.log(`${collection}成功插入${res.result.n}条数据`)
  }
}

new Scan()
