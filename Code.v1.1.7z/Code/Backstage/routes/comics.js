const fs = require('fs')
const Q = require('q')
const express = require('express')
const router = express.Router()
const { MongoClient, ObjectId } = require('mongodb')
const { mongodb, directory } = require('../settings')
const { toResult, toError, toWebPath } = require('../plugin/common')
const fs_readdir = Q.denodeify(fs.readdir)

const collection = 'Comics'

// 根据category字段查询数据,category字段为all时查询全部
router.get('/getComicsList', function (req, res, next) {
  const { category, page, count } = req.query
  MongoClient.connect(mongodb.host, { useUnifiedTopology: true }, (err, db) => {
    if (err) res.json(toError('Connect error'))
    const dbo = db.db(mongodb.database)
    const params = category === 'all' ? {} : { category }
    dbo.collection(collection).find(params).skip(page * count).limit(+count).toArray((err, result) => {
      if (err) res.json(toError('Connect error'))
      const data = result.map(item => ({
        id: item._id,
        category: item.category,
        name: item.name,
        cover: `${toWebPath(item.path)}/Cover.jpg`
      }))
      res.json(toResult(data))
      db.close()
    })
  })
})

// 获取当前项目内所有分集
router.get('/getComicsEpisode', function (req, res, next) {
  const { id } = req.query
  if (!id) res.json(toError('Missing parameters'))
  MongoClient.connect(mongodb.host, { useUnifiedTopology: true }, (err, db) => {
    if (err) res.json(toError('Connect error'))
    const dbo = db.db(mongodb.database)
    dbo.collection(collection).find({ _id: ObjectId(id) }, { projection: { _id: 0 } }).toArray((err, result) => {
      if (err) res.json(toError('Connect error'))
      if (result.length === 0) res.json(toError('Query error'))
      const data = {
        name: result[0].name,
        category: result[0].category,
        cover: `${toWebPath(result[0].path)}/Cover.jpg`,
        episode: result[0].episode
      }
      res.json(toResult(data))
      db.close()
    })
  })
})

// 获取项目内所有文件地址
router.get('/getComicsDetail', function (req, res, next) {
  const { id, episode } = req.query
  if (!id) res.json(toError('Missing parameters'))
  MongoClient.connect(mongodb.host, { useUnifiedTopology: true }, (err, db) => {
    if (err) res.json(toError('Connect error'))
    const dbo = db.db(mongodb.database)
    dbo.collection(collection).find({ _id: ObjectId(id) }).toArray((err, result) => {
      if (err) res.json(toError('Connect error'))
      fs_readdir(`${result[0].path}/${episode}`)
        .then(list => {
          const data = list.map(item => `${toWebPath(result[0].path)}/${episode}/${item}`)
          res.json(toResult(data))
          db.close()
        })
        .catch(err => {
          res.json(toError(err))
        })
    })
  })
})

// 获取分类列表
router.get('/getCategoryList', function (req, res, next) {
  MongoClient.connect(mongodb.host, { useUnifiedTopology: true }, (err, db) => {
    if (err) res.json(toError('Connect error'))
    const dbo = db.db(mongodb.database)
    // 查询category字段不重复的值
    dbo.collection(collection).aggregate([{ $group: { _id : "$category" } }]).toArray((err, result) => {
      if (err) res.json(toError('Connect error'))
      const data = result.map(item => item._id)
      res.json(toResult(data))
      db.close()
    })
  })
})

module.exports = router
