import axios from 'axios'

axios.defaults.baseURL = 'http://10.157.147.41:3000/api'
axios.defaults.timeout = 30000
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8'

// 添加请求拦截器
// axios.interceptors.request.use()

// 添加响应拦截器
// axios.interceptors.response.use()

/**
 * get方法，对应get请求
 * @param {String} url [请求的url地址]
 * @param {Object} params [请求时携带的参数]
 */
export function get (url, params) {
	return new Promise((resolve, reject) => {
		axios({
			method: 'get',
			url,
			params
		})
		.then(res => {
			resolve(res.data)
		}).catch(err => {
			reject(err)
		})
	})
}

/**
 * post方法，对应post请求
 * @param {String} url [请求的url地址]
 * @param {Object} params [请求时携带的参数]
 */
export function post (url, params) {
	return new Promise((resolve, reject) => {
		axios({
			method: 'post',
			url,
			data: params
		})
		.then(res => {
			resolve(res.data)
		})
		.catch(err => {
			reject(err.data)
		})
	})
}
