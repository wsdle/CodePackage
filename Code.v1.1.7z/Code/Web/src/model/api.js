/**
 * api接口统一管理
 */
import { get } from './http'

export const getComicsList = p => get('/comics/getComicsList', p) // 获取全部文件列表
export const getComicsEpisode = p => get('/comics/getComicsEpisode', p) // 获取文件所有分集
export const getComicsDetail = p => get('/comics/getComicsDetail', p) // 获取文件详情
export const getCategoryList = p => get('/comics/getCategoryList', p) // 获取文件分类列表
