<template>
	<div class="page" id="Like"></div>
</template>

<script>
export default {
	name: 'Like'
}
</script>

<style lang="scss" scoped="scoped">
</style>
