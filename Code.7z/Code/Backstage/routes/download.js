const express = require('express')
const router = express.Router()
const fs = require('fs')
const path = require('path')
const { directory } = require('../settings')

router.get('/comics/*', function (req, res, next) {
  const fullPath = path.join(`${directory.root}/Boutique/我的文件${req.path.slice(req.path.indexOf('/', 1))}`)
  res.statusCode = 200
  res.setHeader('Content-Type','text/javascript;charset=UTF-8')
  fs.createReadStream(decodeURIComponent(fullPath)).pipe(res)
})

module.exports = router
