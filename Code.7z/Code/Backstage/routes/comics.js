const fs = require('fs')
const Q = require('q')
const express = require('express')
const router = express.Router()
const { MongoClient, ObjectId } = require('mongodb')
const { mongodb, directory } = require('../settings')
const { toResult, toError, toWebPath } = require('../plugin/common')
const fs_readdir = Q.denodeify(fs.readdir)

const collection = 'Comics'

router.get('/getComicsList', function (req, res, next) {
  MongoClient.connect(mongodb.host, { useUnifiedTopology: true }, (err, db) => {
    if (err) res.json(toError('Connect error'))
    const dbo = db.db(mongodb.database)
    dbo.collection(collection).find({}).toArray((err, result) => {
      if (err) res.json(toError('Connect error'))
      const data = result.map(item => ({
        id: item._id,
        category: item.category,
        name: item.name,
        cover: `${toWebPath(item.path)}/Cover.jpg`
      }))
      res.json(toResult(data))
      db.close()
    })
  })
})

router.get('/getComicsDetail', function (req, res, next) {
  const { id } = req.query
  if (!id) res.json(toError('Missing parameters'))
  MongoClient.connect(mongodb.host, { useUnifiedTopology: true }, (err, db) => {
    if (err) res.json(toError('Connect error'))
    const dbo = db.db(mongodb.database)
    dbo.collection(collection).find({ _id: ObjectId(id) }).toArray((err, result) => {
      if (err) res.json(toError('Connect error'))
      fs_readdir(result[0].path)
        .then(list => {
          const data = list.map(item => `${toWebPath(result[0].path)}/${item}`)
          res.json(toResult(data))
          db.close()
        })
        .catch(err => {
          res.json(toError(err))
        })
    })
  })
})

module.exports = router
