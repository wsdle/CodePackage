const MongoClient = require('mongodb').MongoClient
const Q = require('q')
const { mongodb } = require('../settings')

exports.mongo_connect = function (database, collection) {
  const deferred = Q.defer()
  MongoClient.connect(mongodb.host, { useUnifiedTopology: true }, (err, db) => {
    if (err) {
      deferred.reject(err)
    } else {
      const dbo = db.db(database)
      deferred.resolve({ col: dbo.collection(collection), db })
    }
  })
  return deferred.promise
}

exports.toResult = function (data = null) {
  return {
    message: 'Success',
    state: 0,
    data
  }
}

exports.toError = function (message = 'Error') {
  return {
    message,
    state: 1,
    data: null
  }
}

exports.toWebPath = function (path) {
  return `http://10.157.147.41:3000/download/comics/${path.slice(path.lastIndexOf('我的文件/') + 5)}`
}
