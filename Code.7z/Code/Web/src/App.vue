<template>
  <div id="app" :class="{ 'app-showFooter': isFooter }">
    <div class="app-navigation">
			<van-nav-bar
				:title="title"
				:left-arrow="isReturn"
				border
				@click-left="onClickLeft" />
		</div>
		<div class="app-content">
      <router-view/>
    </div>
		<div class="app-footer">
      <van-tabbar v-model="active" border route>
        <van-tabbar-item icon="wap-home-o" to="/Home" replace>主页</van-tabbar-item>
        <van-tabbar-item icon="like-o" to="/Like" replace>喜爱</van-tabbar-item>
        <van-tabbar-item icon="friends-o" to="/User" replace>个人</van-tabbar-item>
      </van-tabbar>
    </div>
  </div>
</template>

<script>
export default {
  name: 'App',
  data () {
    return {
      active: 0
    }
  },
  methods: {
    // 返回
    onClickLeft () {
      this.$router.go(-1)
    }
  },
  computed: {
    // 标题
    title () {
      return this.$route.meta.name
    },
    // 是否显示返回键
    isReturn () {
      return this.$route.meta.isReturn
    },
    // 是否显示底部标签栏
    isFooter () {
      return this.$route.meta.isFooter
    }
  }
}
</script>

<style lang="scss" scoped="scoped">
@import '@/assets/scss/common.scss';

#app {
	width: 100%;
	height: 100%;
  padding-top: $NavigationHeight;
  background: #EDEEF2;
	box-sizing: border-box;
}

.app-navigation {
	position: fixed;
	top: 0;
	left: 0;
  width: 100%;
  height: $NavigationHeight;
  z-index: 99999;
}

.app-content {
  height: 100%;
}

.app-footer {
  display: none;
  position: fixed;
	bottom: 0;
	left: 0;
  width: 100%;
  height: $FooterHeight;
  z-index: 99999;
}

.app-showFooter {
  padding-bottom: $FooterHeight;

  .app-footer {
    display: block;
  }
}
</style>
