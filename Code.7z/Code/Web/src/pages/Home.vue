<template>
	<div class="page" id="Home">
		<div class="home-list">
			<comics-crad
				v-for="(item, index) in list"
				:key="index"
				:img="item.cover"
				:desc="item.name"
				@on-click="goDetailPage(item.id)">
			</comics-crad>
		</div>
	</div>
</template>

<script>
import { getComicsList } from '@/model/api'
import ComicsCrad from '@/components/ComicsCrad'

export default {
	name: 'Home',
	data () {
		return {
			list: [] // 文件列表
		}
	},
	methods: {
		// 获取文件列表
		getComicsList () {
			getComicsList()
				.then(({ data }) => {
					this.list = data
				})
				.catch(err => {
					throw err
				})
		},
		// 前往详情页
		goDetailPage (id) {
			this.$router.push({
				path: '/Details',
				query: { id }
			})
		}
	},
	mounted () {
		this.getComicsList()
	},
	components: {
		ComicsCrad
	}
}
</script>

<style lang="scss" scoped="scoped">
.home-list {
	overflow: auto;
	width: 100%;
	height: 100%;
}
</style>
