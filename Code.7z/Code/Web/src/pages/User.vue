<template>
	<div class="page" id="User"></div>
</template>

<script>
export default {
	name: 'User'
}
</script>

<style lang="scss" scoped="scoped">
</style>
