<template>
	<div class="page" id="Details">
    <div class="details-list">
      <img
        v-for="(item, index) in list"
        :key="index"
        :src="item">
    </div>
  </div>
</template>

<script>
import { getComicsDetail } from '@/model/api'

export default {
  name: 'Details',
  data () {
    return {
      list: [] // 图片列表
    }
  },
  methods: {
    // 获取文件详情
    getComicsDetail (id) {
      getComicsDetail({ id })
        .then(({ data }) => {
          this.list = data
        })
        .catch(err => {
          throw err
        })
    }
  },
  mounted () {
    this.getComicsDetail(this.$route.query.id)
  }
}
</script>

<style lang="scss" scoped="scoped">
.details-list {
  overflow: auto;
  width: 100%;
  height: 100%;

  img {
    max-width: 100%;
  }
}
</style>
