/**
 * api接口统一管理
 */
import { get } from './http'

export const getComicsList = p => get('/comics/getComicsList', p) // 获取全部文件列表
export const getComicsDetail = p => get('/comics/getComicsDetail', p) // 获取文件详情
