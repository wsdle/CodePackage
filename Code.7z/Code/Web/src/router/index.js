import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/pages/Home' // 主页
import Like from '@/pages/Like' // 喜欢
import User from '@/pages/User' // 个人
import Details from '@/pages/Details' // 详情

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/Home',
      name: 'Home',
      component: Home,
      meta: {
        name: '主页', // 页面标题名
        isReturn: false, // 是否显示返回按钮
        isFooter: true // 是否显示底部标签栏
      }
    },
    {
      path: '/Like',
      name: 'Like',
      component: Like,
      meta: {
        name: '喜爱',
        isReturn: false,
        isFooter: true
      }
    },
    {
      path: '/User',
      name: 'User',
      component: User,
      meta: {
        name: '用户',
        isReturn: false,
        isFooter: true
      }
    },
    {
      path: '/Details',
      name: 'Details',
      component: Details,
      meta: {
        name: '详情',
        isReturn: true,
        isFooter: false
      }
    },
    {
      path: '*',
      redirect: '/Home'
    }
  ]
})
