module.exports = {
  address: {
    host: '10.157.147.41',
    port: '3000'
  },
  directory: {
    Comics: 'G:/Disk/Library/Comics',
    Photo: 'G:/Disk/Library/Photo'
  },
  mongodb: {
    host: 'mongodb://localhost:27017/',
    user: '',
    password: '',
    database: 'BOMU_DB'
  }
}
