const fs = require('fs')
const Q = require('q')
const express = require('express')
const router = express.Router()
const { MongoClient, ObjectId } = require('mongodb')
const { mongodb, directory } = require('../settings')
const { toResult, toError, toWebPath, random, mergeArray, formatVerify } = require('../plugin/common')
const fs_readdir = Q.denodeify(fs.readdir)

const collection = 'Photo'
const toPhotoWebPath = toWebPath(collection)

/*
* 获取筛选列表
* @params[String] category 类别
* @return 如不传参,则返回类别列表,传参返回系列列表
*/
router.get('/getFilterList', function (req, res) {
  const { category } = req.query
  MongoClient.connect(mongodb.host, { useUnifiedTopology: true }, (err, db) => {
    if (err) res.json(toError('Connect error'))
    const dbo = db.db(mongodb.database)
    const whereStr = category === undefined ? {} : { category }
    const group = category === undefined ? { _id: '$category' } : { _id: '$series' }
    dbo.collection(collection).aggregate([ { $match: whereStr }, { $group: group }]).toArray((err, result) => {
      if (err) res.json(toError('Connect error'))
      const data = result.map(item => item._id)
      res.json(toResult(data))
      db.close()
    })
  })
})

/*
* 根据筛选条件查询数据
* @params[String] category 类别,字段为all时查询全部
* @params[String] series 类别,字段为all时查询全部
* @params[Number] page 当前查询页码
* @params[Number] count 每页查询的条数
*/
router.get('/getPhotoList', function (req, res) {
  const { category, series, page, count } = req.query
  MongoClient.connect(mongodb.host, { useUnifiedTopology: true }, (err, db) => {
    if (err) res.json(toError('Connect error'))
    const dbo = db.db(mongodb.database)
    let whereStr = {}
    if (category.toLowerCase() !== 'all') {
      if (series.toLowerCase() === 'all') {
        whereStr = { category }
      } else {
        whereStr = { category, series }
      }
    }
    dbo.collection(collection).find(whereStr).skip(page * count).limit(+count).toArray((err, result) => {
      if (err) res.json(toError('Connect error'))
      const data = result.map(item => ({
        id: item._id,
        category: item.category,
        series: item.series,
        name: item.name,
        cover: toPhotoWebPath(item.cover)
      }))
      res.json(toResult(data))
      db.close()
    })
  })
})

/*
* 获取当前项目内所有分集
* @params[String] id 项目id
*/
router.get('/getPhotoEpisode', function (req, res, next) {
  const { id } = req.query
  if (!id) res.json(toError('Missing parameters'))
  MongoClient.connect(mongodb.host, { useUnifiedTopology: true }, (err, db) => {
    if (err) res.json(toError('Connect error'))
    const dbo = db.db(mongodb.database)
    dbo.collection(collection).find({ _id: ObjectId(id) }, { projection: { _id: 0 } }).toArray((err, result) => {
      if (err) res.json(toError('Connect error'))
      if (result.length === 0) res.json(toError('Query error'))
      const data = {
        name: result[0].name,
        category: result[0].category,
        series: result[0].series,
        cover: toPhotoWebPath(result[0].cover),
        episode: result[0].episode,
        favorite: result[0].favorite
      }
      res.json(toResult(data))
      db.close()
    })
  })
})

/*
* 获取项目内所有文件地址
* @params[String] id 项目id
* @params[String] episode 集数
*/
router.get('/getPhotoImages', function (req, res, next) {
  const { id, episode } = req.query
  if (!id || !episode) res.json(toError('Missing parameters'))
  MongoClient.connect(mongodb.host, { useUnifiedTopology: true }, (err, db) => {
    if (err) res.json(toError('Connect error'))
    const dbo = db.db(mongodb.database)
    dbo.collection(collection).find({ _id: ObjectId(id) }).toArray((err, result) => {
      if (err) res.json(toError('Connect error'))
      fs_readdir(`${result[0].path}/${episode}`)
        .then(list => {
          const data = list.map(item => `${toPhotoWebPath(result[0].path)}/${episode}/${item}`)
          res.json(toResult(data))
          db.close()
        })
        .catch(err => {
          res.json(toError(err))
        })
    })
  })
})

/*
* 随机获取一组图片
*/
router.get('/getPhotoRandomList', function (req, res) {
  MongoClient.connect(mongodb.host, { useUnifiedTopology: true }, (err, db) => {
    if (err) res.json(toError('Connect error'))
    const dbo = db.db(mongodb.database)
    dbo.collection(collection).aggregate([{ $group: { _id: '$_id' } }]).toArray((err, result) => {
      if (err) res.json(toError('Connect error'))
      const id = result[random(result.length - 1)]._id
      dbo.collection(collection).find({ _id: ObjectId(id) }).toArray((err, result) => {
        const info = result[0]
        const dir = info.episode.map(item => `${info.path}/${item}`)
        const pathForEach = dir.map(item => fs_readdir(item))
        Promise.all(pathForEach)
          .then(pathList => {
            const list = mergeArray(dir, pathList).map(item => toPhotoWebPath(item))
            const data = {
              id: id,
              name: info.name,
              favorite: info.favorite,
              list: list.filter(item => formatVerify(item, ['jpg', 'png', 'gif', 'jpeg']))
            }
            res.json(toResult(data))
            db.close()
          })
      })
    })
  })
})

module.exports = router
