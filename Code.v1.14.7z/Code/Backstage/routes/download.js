const express = require('express')
const router = express.Router()
const fs = require('fs')
const path = require('path')
const { directory } = require('../settings')
const { formatVerify } = require('../plugin/common')

/*
* photo文件流获取
*/
router.get('/photo/*', function (req, res, next) {
  const collection = 'Photo'
  // 格式验证
  const format = ['jpg', 'png', 'gif', 'jpeg', 'mp4', 'webm', 'ogg', 'avi', 'rmvb', 'flv', 'wmv', '3gp', 'mkv', 'mov', 'mpg', 'rm', 'swf', 'ts', 'vob', 'mxf']
  if (!formatVerify(req.path, format)) { return null }
  // 文件流传输
  const fullPath = decodeURIComponent(path.join(`${directory[collection]}${req.path.slice(req.path.indexOf('/', 1))}`))
  res.statusCode = 200
  res.setHeader('Content-Type','text/javascript;charset=UTF-8')
  const readFiles = fs.createReadStream(fullPath)
  readFiles.pipe(res)
  readFiles.on('error', err => console.log('Error path: ' + fullPath))
})

/*
* comics文件流获取
*/
router.get('/comics/*', function (req, res, next) {
  const collection = 'Comics'
  // 格式验证
  const format = ['jpg', 'png', 'gif', 'jpeg']
  if (!formatVerify(req.path, format)) { return null }
  // 文件流传输
  const fullPath = decodeURIComponent(path.join(`${directory[collection]}${req.path.slice(req.path.indexOf('/', 1))}`))
  res.statusCode = 200
  res.setHeader('Content-Type','text/javascript;charset=UTF-8')
  const readFiles = fs.createReadStream(fullPath)
  readFiles.pipe(res)
  readFiles.on('error', err => console.log('Error path: ' + fullPath))
})

module.exports = router
