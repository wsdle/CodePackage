const express = require('express')
const router = express.Router()
const { MongoClient, ObjectId } = require('mongodb')
const { mongodb } = require('../settings')
const { toResult, toError,toWebPath } = require('../plugin/common')

/*
* 设置一组项目的喜爱标签
* @params[String] type 类型
* @params[Array] list 项目id列表
* @params[Boolean] value 设置值
*/
router.post('/setFavorite', function (req, res) {
  const { type, list, value } = req.body
  if (!type || !list || value === undefined) res.json(toError('Missing parameters'))
  MongoClient.connect(mongodb.host, { useUnifiedTopology: true }, (err, db) => {
    if (err) res.json(toError('Connect error'))
    const dbo = db.db(mongodb.database)
    const whereStr = { $or: list.map(item => ({ _id: ObjectId(item) })) }
    const updateStr = { $set: { favorite: value } }
    dbo.collection(type).updateMany(whereStr, updateStr, (err, result) => {
      if (err) res.json(toError('Connect error'))
      res.json(result.result.nModified + ' 条文档被更新')
      db.close()
    })
  })
})


/*
* 获取设置喜爱标签的项目
* @params[String] type 类型
*/
router.get('/getFavoriteList', function (req, res) {
  const { type } = req.query
  if (!type) res.json(toError('Missing parameters'))
  MongoClient.connect(mongodb.host, { useUnifiedTopology: true }, (err, db) => {
    if (err) res.json(toError('Connect error'))
    const dbo = db.db(mongodb.database)
    dbo.collection(type).find({ favorite: true }).toArray((err, result) => {
      if (err) res.json(toError('Connect error'))
      const data = result.map(item => ({
        id: item._id,
        category: item.category,
        name: item.name,
        cover: toWebPath(type)(item.cover)
      }))
      res.json(toResult(data))
      db.close()
    })
  })
})

module.exports = router
