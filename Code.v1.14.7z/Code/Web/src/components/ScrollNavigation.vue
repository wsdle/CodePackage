<template>
  <div class="scrollNavigation" :style="{ background }">
    <div class="scrollNavigation-return" @click="prevPage">
      <van-icon name="arrow-left" :color="color" size="1rem"></van-icon>
    </div>
    <div class="scrollNavigation-title">
      <div class="scrollNavigation-title-text" :style="{ color }">
        <div>{{ title }}</div>
        <div>{{ title }}</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    title: { // 标题
      type: String,
      default: ''
    },
    background: { // 背景颜色
      type: String,
      default: '#000000'
    },
    color: { // 文字颜色
      type: String,
      default: '#FFFFFF'
    }
  },
  methods: {
    // 返回上一页
    prevPage () {
      this.$router.go(-1)
      this.$emit('prev-page')
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/assets/scss/common.scss';

.scrollNavigation {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: $NavigationHeight;
  padding: 0 $NavigationHeight;
  line-height: $NavigationHeight;
  box-sizing: border-box;

  &-return {
    position: absolute;
    top: 0;
    left: 0;
    width: $NavigationHeight;
    height: inherit;
    text-align: center;
  }

  &-title {
    overflow: hidden;
    width: 100%;
    height: inherit;

    &-text {
      display: inline-block;
      min-width: 100%;
      height: inherit;
      white-space: nowrap;
      transform: translateX(0);
      animation: HorizontalScroll 12s linear infinite;

      div {
        display: inline-block;
        min-width: 100vw;
        white-space: nowrap;
      }
    }
  }
}

@keyframes HorizontalScroll {
  from {
    transform: translateX(0);
  }
  to {
    transform: translateX(-50%);
  }
}
</style>
