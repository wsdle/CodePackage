// 获取文件格式
export const getFileFormat = function (str) {
  return str.slice(str.lastIndexOf('.') + 1)
}
