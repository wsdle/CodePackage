/**
 * api接口统一管理
 */
import { get, post } from './http'

export const setFavorite = p => post('/universal/setFavorite', p) // 设置喜爱标签
export const getFavoriteList = p => get('/universal/getFavoriteList', p) // 获取设置喜爱的项目列表

export const getPhotoFilterList = p => get('/photo/getFilterList', p) // 获取Photo筛选列表
export const getPhotoList = p => get('/photo/getPhotoList', p) // 获取Photo列表
export const getPhotoEpisode = p => get('/photo/getPhotoEpisode', p) // 获取当前Photo内所有分集
export const getPhotoImages = p => get('/photo/getPhotoImages', p) // 获取Photo内所有文件地址
export const getPhotoRandomList = p => get('/photo/getPhotoRandomList', p) // 随机获取一组图片

export const getComicsList = p => get('/comics/getComicsList', p) // 获取全部文件列表
export const getComicsEpisode = p => get('/comics/getComicsEpisode', p) // 获取文件所有分集
export const getComicsImages = p => get('/comics/getComicsImages', p) // 获取文件内所有图片
export const getComicsCategoryList = p => get('/comics/getCategoryList', p) // 获取文件分类列表
