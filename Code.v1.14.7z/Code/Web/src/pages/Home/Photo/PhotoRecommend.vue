<template>
  <div id="PhotoRecommend">
    <scroll-navigation :title="title" />
    <van-swipe class="photoRecommend-swipe" :loop="false" @change="onChange">
      <van-swipe-item v-for="(image, index) in list" :key="index">
        <van-image
          width="100%"
          height="100%"
          fit="contain"
          lazy-load
          :src="image" />
      </van-swipe-item>
      <template #indicator>
        <div class="photoRecommend-indicator">
          {{ current + 1 }}/{{ list.length }}
        </div>
      </template>
    </van-swipe>
    <div class="photoRecommend-favorite" @click="setFavorite">
      <van-icon v-if="favorite" name="like" color="#FF8D8D" size="1rem" />
      <van-icon v-else name="like-o" color="#FFFFFF" size="1rem" />
    </div>
    <div class="photoRecommend-reset" @click="resetList">
      <van-icon name="replay" color="#FFFFFF" size="1rem" />
    </div>
  </div>
</template>

<script>
import ScrollNavigation from '@/components/ScrollNavigation'
import { getPhotoRandomList, setFavorite } from '@/model/api'

export default {
  name: 'PhotoRecommend',
  data () {
    return {
      id: '', // 当前图片id
      title: '', // 标题
      favorite: false, // 是否标记为喜爱
      list: [], // 图片组
      current: 0 // 当前页码
    }
  },
  methods: {
    // 获取一组图片
    getList () {
      getPhotoRandomList()
        .then(({ data }) => {
          this.id = data.id
          this.title = data.name
          this.favorite = data.favorite
          this.list = data.list
          this.current = 0
        })
        .catch(err => {
          throw err
        })
    },
    // 滑动图片
    onChange (index) {
      this.current = index
    },
    // 添加喜爱标签
    setFavorite () {
      setFavorite({
        type: 'Photo',
        list: [this.id],
        value: !this.favorite
      })
        .then(res => {
          this.favorite = !this.favorite
        })
        .catch(err => {
          throw err
        })
    },
    // 重置图片组
    resetList () {
      this.getList()
    }
  },
  mounted () {
    this.getList()
  },
  components: {
    ScrollNavigation
  }
}
</script>

<style lang="scss" scoped>
@import '@/assets/scss/common.scss';

#PhotoRecommend {
  width: 100%;
  height: 100%;
  padding-top: $NavigationHeight;
  background: #000000;
  box-sizing: border-box;
}

.photoRecommend-swipe {
  width: 100%;
  height: 100%;
}

.photoRecommend-indicator {
  position: absolute;
  bottom: 0.25rem;
  left: 50%;
  padding: 2px 5px;
  color: #FFFFFF;
  font-size: 0.7rem;
  background: rgba(0, 0, 0, 0.2);
  transform: translateX(-50%);
}

.photoRecommend-favorite,
.photoRecommend-reset {
  display: flex;
  justify-content: center;
  align-items: center;
  position: fixed;
  right: 0.25rem;
  width: 2rem;
  height: 2rem;
  border-radius: 1rem;
  background: #000000;
  color: #FFFFFF;
  opacity: 0.6;
}

.photoRecommend-favorite {
  bottom: 4.5rem;
}

.photoRecommend-reset {
  bottom: 2rem;
}
</style>
