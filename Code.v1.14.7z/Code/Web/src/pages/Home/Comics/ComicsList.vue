<template>
	<div class="page" id="ComicsList">
		<van-dropdown-menu class="comicsList-menu">
			<van-dropdown-item v-model="category" :options="categoryOption" @change="switchCategory" />
		</van-dropdown-menu>
		<div class="comicsList-list" @scroll="listScroll" ref="comicsList_list">
			<crad
				v-for="(item, index) in comicsList"
				:key="index"
				:img="item.cover"
				:desc="item.name"
				@on-click="goDetailPage(item.id)">
			</crad>
		</div>
	</div>
</template>

<script>
import { getComicsList, getComicsCategoryList } from '@/model/api'
import Crad from '@/components/Crad'

export default {
	name: 'ComicsList',
	data () {
		return {
			categoryList: [], // 类别列表
			category: 'all', // 选择的类别
			comicsList: [], // 文件列表
			isLoading: false, // 是否加载文件列表中
			page: 0, // 加载的页数
			count: 10, // 每页加载的条数
			scrollTop: 0 // 记录滚动条位置
		}
	},
	methods: {
		// 获取文件列表
		getComicsList () {
			if (this.isLoading) { return false }
			this.isLoading = true
			getComicsList({
				category: this.category,
				page: this.page,
				count: this.count
			})
				.then(({ data }) => {
					if (data.length === 0) {
						this.$toast({
							message: '到底了!  ˋ( ° ▽、° ) ',
							position: 'bottom',
							duration: 800
						})
						return false
					}
					this.comicsList = this.comicsList.concat(data)
					this.page++
				})
				.catch(err => {
					throw err
				})
				.finally(() => {
					this.isLoading = false
				})
		},
		// 前往详情页
		goDetailPage (id) {
			this.$router.push({
				path: '/ComicsDetails',
				query: { id }
			})
		},
		// 调取类别列表
		getCategoryList () {
			getComicsCategoryList()
				.then(({ data }) => {
					this.categoryList = data
				})
				.catch(err => {
					throw err
				})
		},
		// 列表滚动到底部加载数据
		listScroll ({ target }) {
			this.scrollTop = target.scrollTop
			if (target.scrollTop + target.offsetHeight === target.scrollHeight) {
				this.getComicsList()
			}
		},
		// 根据分类筛选
		switchCategory () {
			this.comicsList = []
			this.page = 0
			this.scrollTop = 0
			this.getComicsList()
		}
	},
	computed: {
		// 获取类别列表
		categoryOption () {
			return [{ text: '全部', value: 'all' }].concat(this.categoryList.map(item => ({ text: item, value: item })))
		},
		// 获取ComicsList页滚动条位置
		getComicsListScroll () {
			return this.$store.getters.getComicsListScroll
		}
	},
	mounted () {
		this.getComicsList()
		this.getCategoryList()
	},
	activated () { // 回到页面时触发
		this.$refs.comicsList_list.scrollTop = this.getComicsListScroll
	},
	deactivated () { // 离开页面时触发
		this.$store.commit('setComicsListScroll', this.scrollTop)
	},
	components: {
		Crad
	}
}
</script>

<style lang="scss" scoped="scoped">
@import '@/assets/scss/common.scss';

#ComicsList {
	position: relative;
	padding-top: $menuHeight;
}

.comicsList-menu {
	position: fixed;
	top: $NavigationHeight;
	left: 0;
	width: 100%;
}

.comicsList-list {
	overflow: auto;
	width: 100%;
	height: 100%;
	background: $pageBackground;
}
</style>
