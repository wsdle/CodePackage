<template>
  <div id="LikeAudio">LikeAudio</div>
</template>

<script>
export default {
  name: 'LikeAudio'
}
</script>

<style lang="scss" scoped>

</style>
