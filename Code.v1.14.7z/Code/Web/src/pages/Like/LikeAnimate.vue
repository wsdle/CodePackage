<template>
  <div id="LikeAnimate">LikeAnimate</div>
</template>

<script>
export default {
  name: 'LikeAnimate'
}
</script>

<style lang="scss" scoped>

</style>
