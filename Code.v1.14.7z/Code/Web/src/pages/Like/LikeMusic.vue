<template>
  <div id="LikeMusic">LikeMusic</div>
</template>

<script>
export default {
  name: 'LikeMusic'
}
</script>

<style lang="scss" scoped>

</style>
