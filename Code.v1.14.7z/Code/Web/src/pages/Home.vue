<template>
	<div class="page" id="Home">
		<!-- Benner Start -->
		<van-swipe class="home-benner" :autoplay="3000" indicator-color="white">
			<van-swipe-item>1</van-swipe-item>
			<van-swipe-item>2</van-swipe-item>
		</van-swipe>
		<!-- Benner End -->

		<area-crad
			class="home-area"
			title="分类专区"
			icon="apps-o"
			:list="sortAreaList" />

		<area-crad
			class="home-area"
			title="精品推荐"
			icon="fire-o"
			:list="recommendAreaList" />
	</div>
</template>

<script>
import AreaCrad from '@/components/AreaCrad'

export default {
	name: 'Home',
	data () {
		return {
			sortAreaList: [ // 分类专区内容列表
				{ icon: 'edit', text: '文字', to: '' },
				{ icon: 'volume-o', text: '音频', to: '' },
				{ icon: 'music-o', text: '音频', to: '' },
				{ icon: 'photo-o', text: '图片', to: '/PhotoList' },
				{ icon: 'photo-o', text: '图片', to: '/ComicsList' },
				{ icon: 'tv-o', text: '视频', to: '' },
				{ icon: 'tv-o', text: '视频', to: '' },
				{ icon: 'video-o', text: '视频', to: '' }
			],
			recommendAreaList: [ // 精品推荐内容列表
				{ icon: 'photo-o', text: '图片', to: '/PhotoRecommend' },
				{ icon: 'tv-o', text: '视频', to: '' }
			]
		}
	},
	components: {
		AreaCrad
	}
}
</script>

<style lang="scss" scoped="scoped">
@import '@/assets/scss/common.scss';

.home-benner {
	height: 10rem;
	margin: 0 auto .3rem;
	color: #FFFFFF;
	font-size: 1rem;
	line-height: 10rem;
	text-align: center;
	background-color: #39A9ED;
}

.home-area {
	margin-bottom: .3rem;
}
</style>
