const getters = {
  // 获取Comics页滚动条位置
  getComicsListScroll (state) {
    return state.comicsListScroll
  },
  // 获取Photo页滚动条位置
  getPhotoListScroll (state) {
    return state.photoListScroll
  },
  // 获取Like页选项卡焦点记录
  getLikeActive (state) {
    return state.likeActive
  }
}

export default getters
