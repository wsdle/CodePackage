const MongoClient = require('mongodb').MongoClient
const Q = require('q')
const { address, directory, mongodb } = require('../settings')

exports.mongo_connect = function (database, collection) {
  const deferred = Q.defer()
  MongoClient.connect(mongodb.host, { useUnifiedTopology: true }, (err, db) => {
    if (err) {
      deferred.reject(err)
    } else {
      const dbo = db.db(database)
      deferred.resolve({ col: dbo.collection(collection), db })
    }
  })
  return deferred.promise
}

exports.toResult = function (data = null) {
  return {
    message: 'Success',
    state: 0,
    data
  }
}

exports.toError = function (message = 'Error') {
  return {
    message,
    state: 1,
    data: null
  }
}

// 真实地址转网络地址
exports.toWebPath = function (key) {
  return function (path) {
    const url = `http://${address.host}:${address.port}`
    const lastPath = new RegExp(`${directory[key]}(.*)`).exec(path)[1]
    return `${url}/download/${key.toLowerCase()}${lastPath}`
  }
}

// 一维数组与二维数组合并成路径格式的一维数组
exports.mergeArray = function (arr1, arr2) {
  const result = []
  arr1.forEach((items, i) => {
    arr2[i].forEach(item => {
      result.push(`${items}/${item}`)
    })
  })
  return result
}

// 截取路径中的某一段
exports.cutPath = function (path, num = -1) {
  return path.split('/').slice(num)[0]
}

// 格式验证
exports.formatVerify = function (text, arr) {
  const suffix = text.slice(text.lastIndexOf('.') + 1).toLowerCase()
  return arr.indexOf(suffix) >= 0
}
