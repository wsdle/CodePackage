const fs = require('fs')
const Q = require('q')
const { directory, mongodb } = require('./settings')
const { mongo_connect, mergeArray, cutPath } = require('./plugin/common')

const fs_readdir = Q.denodeify(fs.readdir)

class Scan {
  constructor () {
    const args = process.argv.slice(2)
    this.count = args.length
    console.log('----Scan start----')
    args.forEach(arg => {
      if (this[arg]) {
        this[arg](directory[arg])
          .then(() => this.isOver())
          .catch(err => console.error(err))
      }
    })
  }

  isOver () {
    this.count--
    if (this.count === 0) {
      console.log('----Scan end----')
    }
  }

  async Photo (path) {
    const collection = 'Photo'
    const list1 = await fs_readdir(path)
    const listEach1 = list1.map(item => fs_readdir(`${path}/${item}`))
    const list2 = mergeArray(list1, await Promise.all(listEach1))
    const listEach2 = list2.map(item => fs_readdir(`${path}/${item}`))
    const list3 = mergeArray(list2, await Promise.all(listEach2))
    const listEach3 = list3.map(item => fs_readdir(`${path}/${item}`))
    const list4 = await Promise.all(listEach3)
    const docList = list3.map((items, i) => {
      const doc = {
        category: cutPath(items, -3),
        series: cutPath(items, -2),
        name: cutPath(items, -1),
        path: `${path}/${items}`,
        cover: '',
        episode: [],
        favorite: false
      }
      list4[i].forEach(item => {
        if (/^cover\.(jpg|jpeg|png|gif)$/i.test(item)) {
          doc.cover = `${path}/${items}/${item}`
        } else {
          doc.episode.push(item)
        }
      })
      return doc
    })

    const { col, db } = await mongo_connect(mongodb.database, collection)
    const deferred = Q.defer()
    const updateData = function () {
      col.deleteMany({}, (err) => {
        if (err) deferred.reject(err)
        col.insertMany(docList, (err, obj) => {
          deferred.resolve(obj)
          db.close()
        })
      })
      return deferred.promise
    }
    const res = await updateData()
    console.log(`${collection}成功插入${res.result.n}条数据`)
  }

  async Comics (path) {
    const collection = 'Comics'
    const list1 = await fs_readdir(path)
    const listEach1 = list1.map(item => fs_readdir(`${path}/${item}`))
    const list2 = mergeArray(list1, await Promise.all(listEach1))
    const listEach2 = list2.map(item => fs_readdir(`${path}/${item}`))
    const list3 = await Promise.all(listEach2)
    const docList = list2.map((items, i) => {
      const doc = {
        category: cutPath(items, -2),
        name: cutPath(items, -1),
        path: `${path}/${items}`,
        cover: '',
        episode: [],
        favorite: false
      }
      list3[i].forEach(item => {
        if (/^cover\.(jpg|jpeg|png|gif)$/i.test(item)) {
          doc.cover = `${path}/${items}/${item}`
        } else {
          doc.episode.push(item)
        }
      })
      return doc
    })

    const { col, db } = await mongo_connect(mongodb.database, collection)
    const deferred = Q.defer()
    const updateData = function () {
      col.deleteMany({}, (err) => {
        if (err) deferred.reject(err)
        col.insertMany(docList, (err, obj) => {
          deferred.resolve(obj)
          db.close()
        })
      })
      return deferred.promise
    }
    const res = await updateData()
    console.log(`${collection}成功插入${res.result.n}条数据`)
  }
}

new Scan()
