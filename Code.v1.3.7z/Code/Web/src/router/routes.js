import Home from '@/pages/Home' // 主页
import PhotoList from '@/pages/Home/Photo/PhotoList' // Photo列表
import PhotoDetails from '@/pages/Home/Photo/PhotoDetails' // Photo详情
import PhotoBrowse from '@/pages/Home/Photo/PhotoBrowse' // 浏览Photo
import ComicsList from '@/pages/Home/Comics/ComicsList' // Comics列表
import ComicsDetails from '@/pages/Home/Comics/ComicsDetails' // Comics详情
import ComicsBrowse from '@/pages/Home/Comics/ComicsBrowse' // 浏览Comics
import Like from '@/pages/Like' // 喜欢
import User from '@/pages/User' // 个人

export default [
  // 主页
  {
    path: '/Home',
    name: 'Home',
    component: Home,
    meta: {
      name: '主页', // 页面标题名
      isReturn: false, // 是否显示返回按钮
      isNavigation: true, // 是否显示顶部导航栏
      isFooter: true, // 是否显示底部标签栏
      isKeepAlive: true // 是否缓存
    }
  },
  {
    path: '/PhotoList',
    name: 'PhotoList',
    component: PhotoList,
    meta: {
      name: 'Photo',
      isReturn: true,
      isNavigation: true,
      isFooter: false,
      isKeepAlive: true
    }
  },
  {
    path: '/PhotoDetails',
    name: 'PhotoDetails',
    component: PhotoDetails,
    meta: {
      name: '详情',
      isReturn: true,
      isNavigation: true,
      isFooter: false,
      isKeepAlive: false
    }
  },
  {
    path: '/PhotoBrowse',
    name: 'PhotoBrowse',
    component: PhotoBrowse,
    meta: {
      name: '浏览',
      isReturn: true,
      isNavigation: true,
      isFooter: false,
      isKeepAlive: false
    }
  },
  {
    path: '/ComicsList',
    name: 'ComicsList',
    component: ComicsList,
    meta: {
      name: 'Comics',
      isReturn: true,
      isNavigation: true,
      isFooter: false,
      isKeepAlive: true
    }
  },
  {
    path: '/ComicsDetails',
    name: 'ComicsDetails',
    component: ComicsDetails,
    meta: {
      name: '详情',
      isReturn: true,
      isNavigation: true,
      isFooter: false,
      isKeepAlive: false
    }
  },
  {
    path: '/ComicsBrowse',
    name: 'ComicsBrowse',
    component: ComicsBrowse,
    meta: {
      name: '浏览',
      isReturn: true,
      isNavigation: true,
      isFooter: false,
      isKeepAlive: false
    }
  },
  // 喜爱
  {
    path: '/Like',
    name: 'Like',
    component: Like,
    meta: {
      name: '喜爱',
      isReturn: false,
      isNavigation: true,
      isFooter: true,
      isKeepAlive: false
    }
  },
  // 用户
  {
    path: '/User',
    name: 'User',
    component: User,
    meta: {
      name: '用户',
      isReturn: false,
      isNavigation: true,
      isFooter: true,
      isKeepAlive: false
    }
  },
  {
    path: '*',
    redirect: '/Home'
  }
]
