const state = {
  comicsListScroll: 0, // Comics列表页滚动条位置
  photoListScroll: 0, // Photo列表页滚动条位置
  likeActive: '' // Like页选项卡焦点记录
}

export default state
