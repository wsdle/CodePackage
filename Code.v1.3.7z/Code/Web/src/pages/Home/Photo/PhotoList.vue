<template>
  <div class="page" id="PhotoList">
    <van-dropdown-menu class="photoList-menu">
			<van-dropdown-item v-model="category" :options="categoryOption" @change="switchCategory" />
			<van-dropdown-item v-model="series" :options="seriesOption" @change="switchSeries" />
		</van-dropdown-menu>
		<div class="photoList-list" @scroll="listScroll" ref="photoList_list">
			<crad
				v-for="(item, index) in photoList"
				:key="index"
				:img="item.cover"
				:desc="item.name"
				@on-click="goDetailPage(item.id)">
			</crad>
		</div>
  </div>
</template>

<script>
import Crad from '@/components/Crad'
import { getPhotoFilterList, getPhotoList } from '@/model/api'

export default {
  name: 'PhotoList',
  data () {
    return {
      category: 'all', // 类别
      categoryList: [], // 类别列表
      series: 'all', // 系列
      seriesList: [], // 系列列表
      photoList: [], // 项目列表
      isLoading: false, // 是否加载文件列表中
			page: 0, // 加载的页数
      count: 10, // 每页加载的条数
      scrollTop: 0 // 记录滚动条位置
    }
  },
  methods: {
    // 前往详情页
    goDetailPage (id) {
      this.$router.push({
				path: '/PhotoDetails',
				query: { id }
			})
    },
    // 获取类别列表
    getCategoryList () {
      getPhotoFilterList()
        .then(({ data }) => {
          this.categoryList = data
        })
        .catch(err => {
          throw err
        })
    },
    // 获取系列列表
    getSeriesList () {
      getPhotoFilterList({ category: this.category })
        .then(({ data }) => {
          this.seriesList = data
        })
        .catch(err => {
          throw err
        })
    },
    // 获取Photo列表
    getPhotoList () {
      if (this.isLoading) { return false }
			this.isLoading = true
      getPhotoList({
        category: this.category,
        series: this.series,
        page: this.page,
        count: this.count
      })
        .then(({ data }) => {
          if (data.length === 0) {
						this.$toast({
							message: '到底了!  ˋ( ° ▽、° ) ',
							position: 'bottom',
							duration: 800
						})
						return false
					}
					this.photoList = this.photoList.concat(data)
					this.page++
        })
        .finally(() => {
					this.isLoading = false
				})
    },
    // 列表滚动到底部加载数据
    listScroll ({ target }) {
      this.scrollTop = target.scrollTop
			if (target.scrollTop + target.offsetHeight === target.scrollHeight) {
				this.getPhotoList()
			}
    },
    // 切换类别
    switchCategory () {
      this.series = 'all'
      if (this.category === 'all') this.seriesList = []
      else this.getSeriesList()
      this.page = 0
      this.scrollTop = 0
      this.photoList = []
      this.getPhotoList()
    },
    // 切换系列
    switchSeries () {
      this.page = 0
      this.scrollTop = 0
      this.photoList = []
      this.getPhotoList()
    }
  },
  computed: {
    // 获取类别列表
		categoryOption () {
			return [{ text: '全部', value: 'all' }].concat(this.categoryList.map(item => ({ text: item, value: item })))
    },
    // 获取系列列表
		seriesOption () {
			return [{ text: '全部', value: 'all' }].concat(this.seriesList.map(item => ({ text: item, value: item })))
    },
    // 获取PhotoList页滚动条位置
		getPhotoListScroll () {
			return this.$store.getters.getPhotoListScroll
		}
  },
  mounted () {
    this.getCategoryList()
    this.getPhotoList()
  },
  activated () { // 回到页面时触发
		this.$refs.photoList_list.scrollTop = this.getPhotoListScroll
	},
	deactivated () { // 离开页面时触发
		this.$store.commit('setPhotoListScroll', this.scrollTop)
	},
  components: {
    Crad
  }
}
</script>

<style lang="scss" scoped>
@import '@/assets/scss/common.scss';

#PhotoList {
	position: relative;
	padding-top: $menuHeight;
}

.photoList-menu {
	position: fixed;
	top: $NavigationHeight;
	left: 0;
	width: 100%;
}

.photoList-list {
	overflow: auto;
	width: 100%;
	height: 100%;
	background: $pageBackground;
}
</style>
