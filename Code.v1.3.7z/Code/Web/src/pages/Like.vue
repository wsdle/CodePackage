<template>
	<div class="page" id="Like">
		<van-tabs
			class="like-tabs"
			v-model="active"
			swipeable
			sticky
			@change="switchPage">
			<van-tab
				class="like-tab"
				v-for="(item, index) in pageList"
				:key="index"
				:title="item.title">
				<component :is="item.component"></component>
			</van-tab>
		</van-tabs>
	</div>
</template>

<script>
import LikeFiction from '@/pages/Like/LikeFiction'
import LikeAudio from '@/pages/Like/LikeAudio'
import LikeMusic from '@/pages/Like/LikeMusic'
import LikePhoto from '@/pages/Like/LikePhoto'
import LikeComics from '@/pages/Like/LikeComics'
import LikeAnimate from '@/pages/Like/LikeAnimate'
import LikeVideo from '@/pages/Like/LikeVideo'
import LikeMovie from '@/pages/Like/LikeMovie'

export default {
	name: 'Like',
	data () {
		return {
			active: 0, // 当前选择的页面
			pageList: [ // 页面列表
				{ title: 'Fiction', component: 'LikeFiction' },
				{ title: 'Audio', component: 'LikeAudio' },
				{ title: 'Music', component: 'LikeMusic' },
				{ title: 'Photo', component: 'LikePhoto' },
				{ title: 'Comics', component: 'LikeComics' },
				{ title: 'Animate', component: 'LikeAnimate' },
				{ title: 'Video', component: 'LikeVideo' },
				{ title: 'Movie', component: 'LikeMovie' }
			]
		}
	},
	methods: {
		// 切换页面
		switchPage (index) {
			this.active = index
			this.$store.commit('setLikeActive', index)
		}
	},
	mounted () {
		this.active = this.$store.getters.getLikeActive
	},
	components: {
		LikeFiction,
		LikeAudio,
		LikeMusic,
		LikePhoto,
		LikeComics,
		LikeAnimate,
		LikeVideo,
		LikeMovie
	}
}
</script>

<style lang="scss" scoped="scoped">
@import '@/assets/scss/common.scss';

.like-tabs {
	height: 100%;
}

.like-tab {
	overflow-y: auto;
	height: calc(100vh - 140px);
}
</style>
