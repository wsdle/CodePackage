<template>
  <div id="LikeVideo">LikeVideo</div>
</template>

<script>
export default {
  name: 'LikeVideo'
}
</script>

<style lang="scss" scoped>

</style>
