<template>
  <div class="areaCrad">
    <div class="areaCrad-title">
      <van-icon class="areaCrad-title-icon" :name="icon" />
      <span class="areaCrad-title-text">{{ title }}</span>
    </div>
    <van-grid :column-num="4" border>
      <van-grid-item
        v-for="(item, index) in list"
        :key="index"
        :icon="item.icon"
        :text="item.text"
        :to="item.to" />
    </van-grid>
  </div>
</template>

<script>
export default {
  props: {
    title: { // 区域标题
      type: String,
      default: ''
    },
    icon: { // 区域图表
      type: String,
      default: ''
    },
    list: { // 单元格
      type: Array,
      required: true
      // default: function () {
      //   return [{
      //     icon: '',
      //     text: '',
      //     to: ''
      //   }]
      // }
    }
  }
}
</script>

<style lang="scss" scoped>
.areaCrad {
  width: 100%;
  height: auto;
  background: #FFFFFF;

  &-title {
    display: flex;
    align-items: center;
    height: 2rem;
    padding: 0 1rem;
    color: #666666;
    box-sizing: border-box;

    &-icon {
      margin-right: 0.2rem;
      font-size: 1rem;
    }

    &-text {
      font-size: .9rem;
    }
  }
}
</style>
